# Daily Sales Report Management System

## Overview

A daily sales activity tracking and reporting system for sales teams. The application allows sales executives to log their daily activities including morning syncs, lead generation, cold calling, demos, and conversions. It provides a dashboard for quick metrics overview, a form for creating/editing reports, and a list view for browsing historical reports.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite as the build tool
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming (light/dark mode support)
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **API Design**: RESTful JSON API endpoints under `/api/*` prefix
- **Build**: esbuild for server bundling, Vite for client bundling
- **Development**: tsx for TypeScript execution in development

### Data Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema Location**: `shared/schema.ts` contains all table definitions
- **Validation**: drizzle-zod for generating Zod schemas from Drizzle tables
- **Storage Pattern**: Storage interface abstraction (`IStorage`) with in-memory implementation for development

### Project Structure
```
client/           # React frontend application
  src/
    components/   # UI components (shadcn/ui + custom)
    pages/        # Route page components
    hooks/        # Custom React hooks
    lib/          # Utility functions and query client
server/           # Express backend
  index.ts        # Server entry point
  routes.ts       # API route definitions
  storage.ts      # Data storage implementation
shared/           # Shared code between client/server
  schema.ts       # Drizzle schema and Zod types
```

### Key Design Decisions
1. **Monorepo Structure**: Client and server in single repo with shared types via `@shared/*` path alias
2. **Type Safety**: End-to-end TypeScript with Zod schemas shared between frontend validation and backend API
3. **Component Library**: shadcn/ui provides accessible, customizable components that can be modified directly in codebase
4. **Storage Abstraction**: Interface-based storage allows swapping between in-memory (dev) and PostgreSQL (prod) implementations

## External Dependencies

### Database
- **PostgreSQL**: Primary database, configured via `DATABASE_URL` environment variable
- **Drizzle Kit**: Database migrations stored in `./migrations` directory
- **Schema Push**: Use `npm run db:push` to sync schema to database

### UI/Component Libraries
- **Radix UI**: Headless component primitives for accessibility
- **Lucide React**: Icon library
- **date-fns**: Date formatting and manipulation
- **embla-carousel-react**: Carousel functionality
- **vaul**: Drawer component
- **cmdk**: Command palette component

### Development Tools
- **Replit Plugins**: `@replit/vite-plugin-runtime-error-modal`, `@replit/vite-plugin-cartographer`, `@replit/vite-plugin-dev-banner` for enhanced Replit development experience

### Build & Runtime
- **Vite**: Frontend bundling and dev server
- **esbuild**: Server bundling for production
- **tsx**: TypeScript execution for development