import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { format, parseISO } from "date-fns";
import {
  Clock,
  Users,
  Phone,
  Presentation,
  FileText,
  CheckCircle,
  Calendar,
  Pencil,
  ArrowLeft,
  Loader2,
  Mail,
  MessageSquare,
  Target,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import type { DailyReport } from "@shared/schema";

interface SectionDisplayProps {
  number: number;
  title: string;
  timeRange: string;
  icon: React.ElementType;
  children: React.ReactNode;
}

function SectionDisplay({
  number,
  title,
  timeRange,
  icon: Icon,
  children,
}: SectionDisplayProps) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary font-semibold">
            {number}
          </div>
          <div>
            <CardTitle className="text-lg font-semibold flex items-center gap-2">
              <Icon className="h-5 w-5 text-muted-foreground" />
              {title}
            </CardTitle>
            <p className="text-sm text-muted-foreground">{timeRange}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">{children}</CardContent>
    </Card>
  );
}

function MetricRow({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: string | number | boolean | null | undefined;
  icon?: React.ElementType;
}) {
  if (value === null || value === undefined || value === "") return null;

  const displayValue =
    typeof value === "boolean" ? (value ? "Yes" : "No") : String(value);

  return (
    <div className="flex items-center justify-between py-2">
      <div className="flex items-center gap-2 text-muted-foreground">
        {Icon && <Icon className="h-4 w-4" />}
        <span>{label}</span>
      </div>
      <span className="font-medium" data-testid={`text-${label.toLowerCase().replace(/\s+/g, "-")}`}>
        {displayValue}
      </span>
    </div>
  );
}

function TextBlock({
  label,
  value,
}: {
  label: string;
  value: string | null | undefined;
}) {
  if (!value) return null;

  return (
    <div className="space-y-2">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="text-sm bg-muted/50 rounded-lg p-3">{value}</p>
    </div>
  );
}

export default function ViewReport() {
  const { id } = useParams<{ id: string }>();

  const { data: report, isLoading, error } = useQuery<DailyReport>({
    queryKey: ["/api/reports", id],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error || !report) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <FileText className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-medium mb-2">Report not found</h3>
            <p className="text-muted-foreground mb-6">
              The report you're looking for doesn't exist or has been deleted.
            </p>
            <Button asChild data-testid="button-back-to-reports">
              <Link href="/reports">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Reports
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const leadStatusColors: Record<string, string> = {
    negotiation: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400",
    waiting: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
    decision: "bg-purple-500/10 text-purple-700 dark:text-purple-400",
    closed: "bg-green-500/10 text-green-700 dark:text-green-400",
    lost: "bg-red-500/10 text-red-700 dark:text-red-400",
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" asChild data-testid="button-back">
            <Link href="/reports">
              <ArrowLeft className="h-5 w-5" />
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-semibold" data-testid="text-view-report-title">
              Daily Report
            </h1>
            <p className="text-muted-foreground">
              View sales activity details
            </p>
          </div>
        </div>
        <Button asChild data-testid="button-edit-report">
          <Link href={`/reports/${id}/edit`}>
            <Pencil className="h-4 w-4 mr-2" />
            Edit Report
          </Link>
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h2 className="text-xl font-semibold" data-testid="text-executive-name">
                  {report.executiveName}
                </h2>
                <p className="text-muted-foreground" data-testid="text-report-date">
                  {format(parseISO(report.date), "EEEE, MMMM d, yyyy")}
                </p>
              </div>
            </div>
            {report.leadStatus && (
              <Badge
                className={leadStatusColors[report.leadStatus] || ""}
                data-testid="badge-lead-status"
              >
                {report.leadStatus.charAt(0).toUpperCase() + report.leadStatus.slice(1)}
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="pt-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <Phone className="h-5 w-5 text-primary" />
              </div>
              <p className="text-3xl font-bold" data-testid="text-summary-calls">
                {report.totalCalls || 0}
              </p>
              <p className="text-sm text-muted-foreground">Total Calls</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <Presentation className="h-5 w-5 text-primary" />
              </div>
              <p className="text-3xl font-bold" data-testid="text-summary-demos">
                {report.totalDemos || 0}
              </p>
              <p className="text-sm text-muted-foreground">Total Demos</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <Target className="h-5 w-5 text-primary" />
              </div>
              <p className="text-3xl font-bold" data-testid="text-summary-converted">
                {report.leadsConverted || 0}
              </p>
              <p className="text-sm text-muted-foreground">Leads Converted</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <Mail className="h-5 w-5 text-primary" />
              </div>
              <p className="text-3xl font-bold" data-testid="text-summary-emails">
                {report.emailsSent || 0}
              </p>
              <p className="text-sm text-muted-foreground">Emails Sent</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <SectionDisplay
        number={1}
        title="Morning Start & Team Sync"
        timeRange="9:00 - 9:30 AM"
        icon={Clock}
      >
        <TextBlock label="Target for today" value={report.targetForToday} />
        <TextBlock
          label="Yesterday performance summary"
          value={report.yesterdayPerformance}
        />
        <TextBlock label="New leads assigned" value={report.newLeadsAssigned} />
        {!report.targetForToday &&
          !report.yesterdayPerformance &&
          !report.newLeadsAssigned && (
            <p className="text-sm text-muted-foreground italic">
              No data recorded for this section
            </p>
          )}
      </SectionDisplay>

      <SectionDisplay
        number={2}
        title="Lead Generation & CRM Update"
        timeRange="9:30 - 11:00 AM"
        icon={Users}
      >
        <MetricRow label="Leads added to CRM" value={report.leadsAddedToCRM} />
        <MetricRow label="Lead source" value={report.leadSource} />
        <MetricRow label="Introductions sent" value={report.introductionsSent} />
        {!report.leadsAddedToCRM &&
          !report.leadSource &&
          !report.introductionsSent && (
            <p className="text-sm text-muted-foreground italic">
              No data recorded for this section
            </p>
          )}
      </SectionDisplay>

      <SectionDisplay
        number={3}
        title="Cold Calling / WhatsApp / Email Follow-Ups"
        timeRange="11:00 AM - 1:30 PM"
        icon={Phone}
      >
        <MetricRow
          label="Total calls made"
          value={report.totalCallsMade}
          icon={Phone}
        />
        <MetricRow
          label="Meaningful conversations"
          value={report.meaningfulConversations}
        />
        <MetricRow
          label="WhatsApp messages sent"
          value={report.whatsappMessagesSent}
          icon={MessageSquare}
        />
        <MetricRow label="Emails sent" value={report.emailsSent} icon={Mail} />
        <MetricRow label="Free demos offered" value={report.freeDemosOffered} />
        <TextBlock label="Demos scheduled" value={report.demosScheduled} />
      </SectionDisplay>

      <SectionDisplay
        number={4}
        title="Product Demos & Client Meetings"
        timeRange="2:15 - 5:15 PM"
        icon={Presentation}
      >
        <MetricRow
          label="Zoom/Onsite demos conducted"
          value={report.zoomDemosConducted}
        />
        <MetricRow label="Clients met" value={report.clientsMet} />
        <MetricRow
          label="Pricing/features explained"
          value={report.pricingExplained}
        />
        <TextBlock
          label="Testimonials/success stories shared"
          value={report.testimonialsShared}
        />
      </SectionDisplay>

      <SectionDisplay
        number={5}
        title="Quotation / Proposal / Invoice Sending"
        timeRange="5:15 - 5:45 PM"
        icon={FileText}
      >
        <MetricRow label="Quotations sent" value={report.quotationsSent} />
        <MetricRow label="Proposals created" value={report.proposalsCreated} />
        <MetricRow label="Invoices shared" value={report.invoicesShared} />
        <MetricRow label="Lead status" value={report.leadStatus} />
      </SectionDisplay>

      <SectionDisplay
        number={6}
        title="Daily Wrap-Up"
        timeRange="5:45 - 6:00 PM"
        icon={CheckCircle}
      >
        <MetricRow label="Total calls" value={report.totalCalls} icon={Phone} />
        <MetricRow
          label="Total demos"
          value={report.totalDemos}
          icon={Presentation}
        />
        <MetricRow
          label="Leads converted"
          value={report.leadsConverted}
          icon={Target}
        />
        <Separator className="my-4" />
        <TextBlock
          label="Pending follow-up tasks for tomorrow"
          value={report.pendingFollowUp}
        />
        <TextBlock label="Notes / Remarks" value={report.notes} />
      </SectionDisplay>
    </div>
  );
}
