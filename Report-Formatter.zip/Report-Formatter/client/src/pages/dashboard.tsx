import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import {
  Phone,
  Users,
  TrendingUp,
  FileText,
  Calendar,
  ArrowRight,
  Mail,
  MessageSquare,
  PlusCircle,
} from "lucide-react";
import type { DailyReport } from "@shared/schema";
import { format, parseISO } from "date-fns";

function MetricCard({
  title,
  value,
  icon: Icon,
  description,
  isLoading,
}: {
  title: string;
  value: number | string;
  icon: React.ElementType;
  description?: string;
  isLoading?: boolean;
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Skeleton className="h-8 w-20" />
        ) : (
          <div className="text-3xl font-bold" data-testid={`text-metric-${title.toLowerCase().replace(/\s+/g, "-")}`}>
            {value}
          </div>
        )}
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
      </CardContent>
    </Card>
  );
}

function RecentReportsTable({
  reports,
  isLoading,
}: {
  reports: DailyReport[];
  isLoading: boolean;
}) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    );
  }

  if (reports.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <FileText className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium mb-2">No reports yet</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Create your first daily sales report to get started
        </p>
        <Button asChild data-testid="button-create-first-report">
          <Link href="/new-report">
            <PlusCircle className="h-4 w-4 mr-2" />
            Create Report
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {reports.slice(0, 5).map((report) => (
        <Link
          key={report.id}
          href={`/reports/${report.id}`}
          data-testid={`row-report-${report.id}`}
        >
          <div className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover-elevate active-elevate-2 cursor-pointer">
            <div className="flex items-center gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Calendar className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-medium">{report.executiveName}</p>
                <p className="text-sm text-muted-foreground">
                  {format(parseISO(report.date), "MMMM d, yyyy")}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="hidden md:flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{report.totalCalls || 0} calls</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span>{report.totalDemos || 0} demos</span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  <span>{report.leadsConverted || 0} converted</span>
                </div>
              </div>
              <ArrowRight className="h-4 w-4 text-muted-foreground" />
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const { data: reports = [], isLoading } = useQuery<DailyReport[]>({
    queryKey: ["/api/reports"],
  });

  const todaysTotals = reports.reduce(
    (acc, report) => ({
      totalCalls: acc.totalCalls + (report.totalCalls || 0),
      totalDemos: acc.totalDemos + (report.totalDemos || 0),
      leadsConverted: acc.leadsConverted + (report.leadsConverted || 0),
      emailsSent: acc.emailsSent + (report.emailsSent || 0),
      whatsappMessages: acc.whatsappMessages + (report.whatsappMessagesSent || 0),
    }),
    { totalCalls: 0, totalDemos: 0, leadsConverted: 0, emailsSent: 0, whatsappMessages: 0 }
  );

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold" data-testid="text-page-title">
            Dashboard
          </h1>
          <p className="text-muted-foreground">
            Overview of your sales team performance
          </p>
        </div>
        <Button asChild data-testid="button-new-report-dashboard">
          <Link href="/new-report">
            <PlusCircle className="h-4 w-4 mr-2" />
            New Report
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total Calls"
          value={todaysTotals.totalCalls}
          icon={Phone}
          description="Across all reports"
          isLoading={isLoading}
        />
        <MetricCard
          title="Total Demos"
          value={todaysTotals.totalDemos}
          icon={Users}
          description="Demos conducted"
          isLoading={isLoading}
        />
        <MetricCard
          title="Leads Converted"
          value={todaysTotals.leadsConverted}
          icon={TrendingUp}
          description="Successful conversions"
          isLoading={isLoading}
        />
        <MetricCard
          title="Reports"
          value={reports.length}
          icon={FileText}
          description="Total submissions"
          isLoading={isLoading}
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <MetricCard
          title="Emails Sent"
          value={todaysTotals.emailsSent}
          icon={Mail}
          description="Email outreach"
          isLoading={isLoading}
        />
        <MetricCard
          title="WhatsApp Messages"
          value={todaysTotals.whatsappMessages}
          icon={MessageSquare}
          description="Instant messaging"
          isLoading={isLoading}
        />
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2">
          <div>
            <CardTitle>Recent Reports</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Latest daily sales submissions
            </p>
          </div>
          {reports.length > 0 && (
            <Button variant="ghost" asChild data-testid="link-view-all-reports">
              <Link href="/reports">
                View All
                <ArrowRight className="h-4 w-4 ml-2" />
              </Link>
            </Button>
          )}
        </CardHeader>
        <CardContent>
          <RecentReportsTable reports={reports} isLoading={isLoading} />
        </CardContent>
      </Card>
    </div>
  );
}
