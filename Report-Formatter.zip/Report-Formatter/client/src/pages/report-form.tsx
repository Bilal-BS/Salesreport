import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation, useParams } from "wouter";
import { format } from "date-fns";
import { z } from "zod";
import {
  Clock,
  Users,
  Phone,
  Presentation,
  FileText,
  CheckCircle,
  Calendar,
  ChevronDown,
  ChevronUp,
  Loader2,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { DailyReport, InsertDailyReport } from "@shared/schema";
import { cn } from "@/lib/utils";

const reportFormSchema = z.object({
  date: z.string().min(1, "Date is required"),
  executiveName: z.string().min(1, "Executive name is required"),
  targetForToday: z.string().optional(),
  yesterdayPerformance: z.string().optional(),
  newLeadsAssigned: z.string().optional(),
  leadsAddedToCRM: z.coerce.number().min(0).default(0),
  leadSource: z.string().optional(),
  introductionsSent: z.coerce.number().min(0).default(0),
  totalCallsMade: z.coerce.number().min(0).default(0),
  meaningfulConversations: z.coerce.number().min(0).default(0),
  whatsappMessagesSent: z.coerce.number().min(0).default(0),
  emailsSent: z.coerce.number().min(0).default(0),
  freeDemosOffered: z.coerce.number().min(0).default(0),
  demosScheduled: z.string().optional(),
  zoomDemosConducted: z.coerce.number().min(0).default(0),
  clientsMet: z.coerce.number().min(0).default(0),
  pricingExplained: z.boolean().default(false),
  testimonialsShared: z.string().optional(),
  quotationsSent: z.coerce.number().min(0).default(0),
  proposalsCreated: z.coerce.number().min(0).default(0),
  invoicesShared: z.coerce.number().min(0).default(0),
  leadStatus: z.string().optional(),
  totalCalls: z.coerce.number().min(0).default(0),
  totalDemos: z.coerce.number().min(0).default(0),
  leadsConverted: z.coerce.number().min(0).default(0),
  pendingFollowUp: z.string().optional(),
  notes: z.string().optional(),
});

type ReportFormValues = z.infer<typeof reportFormSchema>;

interface SectionProps {
  number: number;
  title: string;
  timeRange: string;
  icon: React.ElementType;
  children: React.ReactNode;
  isExpanded: boolean;
  onToggle: () => void;
  hasContent: boolean;
}

function FormSection({
  number,
  title,
  timeRange,
  icon: Icon,
  children,
  isExpanded,
  onToggle,
  hasContent,
}: SectionProps) {
  return (
    <Card className="overflow-visible">
      <CardHeader
        className="cursor-pointer hover-elevate"
        onClick={onToggle}
      >
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary font-semibold">
              {number}
            </div>
            <div>
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Icon className="h-5 w-5 text-muted-foreground" />
                {title}
              </CardTitle>
              <p className="text-sm text-muted-foreground">{timeRange}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {hasContent && (
              <div className="h-2 w-2 rounded-full bg-green-500" />
            )}
            {isExpanded ? (
              <ChevronUp className="h-5 w-5 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-5 w-5 text-muted-foreground" />
            )}
          </div>
        </div>
      </CardHeader>
      {isExpanded && (
        <CardContent className="pt-0 space-y-4">{children}</CardContent>
      )}
    </Card>
  );
}

function NumberInput({
  label,
  name,
  form,
}: {
  label: string;
  name: keyof ReportFormValues;
  form: ReturnType<typeof useForm<ReportFormValues>>;
}) {
  return (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input
              type="number"
              min={0}
              {...field}
              value={field.value || 0}
              onChange={(e) => field.onChange(Number(e.target.value) || 0)}
              className="w-32"
              data-testid={`input-${name}`}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );
}

export default function ReportForm() {
  const { id } = useParams<{ id?: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const isEditing = Boolean(id);

  const [expandedSections, setExpandedSections] = useState<number[]>([1]);

  const { data: existingReport, isLoading: isLoadingReport } = useQuery<DailyReport>({
    queryKey: ["/api/reports", id],
    enabled: isEditing,
  });

  const form = useForm<ReportFormValues>({
    resolver: zodResolver(reportFormSchema),
    defaultValues: {
      date: format(new Date(), "yyyy-MM-dd"),
      executiveName: "",
      targetForToday: "",
      yesterdayPerformance: "",
      newLeadsAssigned: "",
      leadsAddedToCRM: 0,
      leadSource: "",
      introductionsSent: 0,
      totalCallsMade: 0,
      meaningfulConversations: 0,
      whatsappMessagesSent: 0,
      emailsSent: 0,
      freeDemosOffered: 0,
      demosScheduled: "",
      zoomDemosConducted: 0,
      clientsMet: 0,
      pricingExplained: false,
      testimonialsShared: "",
      quotationsSent: 0,
      proposalsCreated: 0,
      invoicesShared: 0,
      leadStatus: "",
      totalCalls: 0,
      totalDemos: 0,
      leadsConverted: 0,
      pendingFollowUp: "",
      notes: "",
    },
  });

  useEffect(() => {
    if (existingReport) {
      form.reset({
        date: existingReport.date,
        executiveName: existingReport.executiveName,
        targetForToday: existingReport.targetForToday || "",
        yesterdayPerformance: existingReport.yesterdayPerformance || "",
        newLeadsAssigned: existingReport.newLeadsAssigned || "",
        leadsAddedToCRM: existingReport.leadsAddedToCRM || 0,
        leadSource: existingReport.leadSource || "",
        introductionsSent: existingReport.introductionsSent || 0,
        totalCallsMade: existingReport.totalCallsMade || 0,
        meaningfulConversations: existingReport.meaningfulConversations || 0,
        whatsappMessagesSent: existingReport.whatsappMessagesSent || 0,
        emailsSent: existingReport.emailsSent || 0,
        freeDemosOffered: existingReport.freeDemosOffered || 0,
        demosScheduled: existingReport.demosScheduled || "",
        zoomDemosConducted: existingReport.zoomDemosConducted || 0,
        clientsMet: existingReport.clientsMet || 0,
        pricingExplained: existingReport.pricingExplained || false,
        testimonialsShared: existingReport.testimonialsShared || "",
        quotationsSent: existingReport.quotationsSent || 0,
        proposalsCreated: existingReport.proposalsCreated || 0,
        invoicesShared: existingReport.invoicesShared || 0,
        leadStatus: existingReport.leadStatus || "",
        totalCalls: existingReport.totalCalls || 0,
        totalDemos: existingReport.totalDemos || 0,
        leadsConverted: existingReport.leadsConverted || 0,
        pendingFollowUp: existingReport.pendingFollowUp || "",
        notes: existingReport.notes || "",
      });
    }
  }, [existingReport, form]);

  const createMutation = useMutation({
    mutationFn: (data: InsertDailyReport) =>
      apiRequest("POST", "/api/reports", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      toast({
        title: "Report created",
        description: "Your daily sales report has been saved successfully.",
      });
      navigate("/reports");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertDailyReport) =>
      apiRequest("PUT", `/api/reports/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reports", id] });
      toast({
        title: "Report updated",
        description: "Your changes have been saved successfully.",
      });
      navigate("/reports");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update report. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: ReportFormValues) => {
    if (isEditing) {
      updateMutation.mutate(values as InsertDailyReport);
    } else {
      createMutation.mutate(values as InsertDailyReport);
    }
  };

  const toggleSection = (section: number) => {
    setExpandedSections((prev) =>
      prev.includes(section)
        ? prev.filter((s) => s !== section)
        : [...prev, section]
    );
  };

  const watchedValues = form.watch();
  const completedSections = [
    watchedValues.targetForToday || watchedValues.yesterdayPerformance,
    watchedValues.leadsAddedToCRM > 0 || watchedValues.introductionsSent > 0,
    watchedValues.totalCallsMade > 0 || watchedValues.emailsSent > 0,
    watchedValues.zoomDemosConducted > 0 || watchedValues.clientsMet > 0,
    watchedValues.quotationsSent > 0 || watchedValues.proposalsCreated > 0,
    watchedValues.totalCalls > 0 || watchedValues.leadsConverted > 0,
  ].filter(Boolean).length;

  const progressPercent = Math.round((completedSections / 6) * 100);

  const isPending = createMutation.isPending || updateMutation.isPending;

  if (isEditing && isLoadingReport) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold" data-testid="text-form-title">
            {isEditing ? "Edit Report" : "New Daily Report"}
          </h1>
          <p className="text-muted-foreground">
            {isEditing
              ? "Update your daily sales activities"
              : "Record your daily sales activities and metrics"}
          </p>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Form Progress</span>
            <span className="text-sm text-muted-foreground">
              {completedSections}/6 sections
            </span>
          </div>
          <Progress value={progressPercent} className="h-2" />
        </CardContent>
      </Card>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <Card>
            <CardContent className="pt-6">
              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Report Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={cn(
                                "justify-start text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                              data-testid="input-date"
                            >
                              <Calendar className="mr-2 h-4 w-4" />
                              {field.value
                                ? format(new Date(field.value), "PPP")
                                : "Pick a date"}
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <CalendarComponent
                            mode="single"
                            selected={field.value ? new Date(field.value) : undefined}
                            onSelect={(date) =>
                              field.onChange(date ? format(date, "yyyy-MM-dd") : "")
                            }
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="executiveName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sales Executive Name</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter your name"
                          {...field}
                          data-testid="input-executive-name"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </CardContent>
          </Card>

          <FormSection
            number={1}
            title="Morning Start & Team Sync"
            timeRange="9:00 - 9:30 AM"
            icon={Clock}
            isExpanded={expandedSections.includes(1)}
            onToggle={() => toggleSection(1)}
            hasContent={Boolean(watchedValues.targetForToday || watchedValues.yesterdayPerformance)}
          >
            <FormField
              control={form.control}
              name="targetForToday"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Target for today</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Enter your targets for today..."
                      {...field}
                      data-testid="input-target-for-today"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="yesterdayPerformance"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Yesterday performance summary</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Summarize yesterday's performance..."
                      {...field}
                      data-testid="input-yesterday-performance"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="newLeadsAssigned"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>New leads assigned</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="Enter new leads..."
                      {...field}
                      data-testid="input-new-leads-assigned"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </FormSection>

          <FormSection
            number={2}
            title="Lead Generation & CRM Update"
            timeRange="9:30 - 11:00 AM"
            icon={Users}
            isExpanded={expandedSections.includes(2)}
            onToggle={() => toggleSection(2)}
            hasContent={watchedValues.leadsAddedToCRM > 0 || watchedValues.introductionsSent > 0}
          >
            <div className="grid gap-4 md:grid-cols-2">
              <NumberInput label="Leads added to CRM" name="leadsAddedToCRM" form={form} />
              <NumberInput label="Introductions sent" name="introductionsSent" form={form} />
            </div>
            <FormField
              control={form.control}
              name="leadSource"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Lead source</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value || ""}>
                    <FormControl>
                      <SelectTrigger data-testid="select-lead-source">
                        <SelectValue placeholder="Select lead source" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="google">Google</SelectItem>
                      <SelectItem value="linkedin">LinkedIn</SelectItem>
                      <SelectItem value="directories">Directories</SelectItem>
                      <SelectItem value="referrals">Referrals</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </FormSection>

          <FormSection
            number={3}
            title="Cold Calling / WhatsApp / Email Follow-Ups"
            timeRange="11:00 AM - 1:30 PM"
            icon={Phone}
            isExpanded={expandedSections.includes(3)}
            onToggle={() => toggleSection(3)}
            hasContent={
              watchedValues.totalCallsMade > 0 ||
              watchedValues.emailsSent > 0 ||
              watchedValues.whatsappMessagesSent > 0
            }
          >
            <div className="grid gap-4 md:grid-cols-2">
              <NumberInput label="Total calls made" name="totalCallsMade" form={form} />
              <NumberInput
                label="Meaningful conversations (15-20 min)"
                name="meaningfulConversations"
                form={form}
              />
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <NumberInput label="WhatsApp messages sent" name="whatsappMessagesSent" form={form} />
              <NumberInput label="Emails sent" name="emailsSent" form={form} />
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <NumberInput label="Free demos offered" name="freeDemosOffered" form={form} />
              <FormField
                control={form.control}
                name="demosScheduled"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Demos scheduled for next day</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter scheduled demos..."
                        {...field}
                        data-testid="input-demos-scheduled"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </FormSection>

          <FormSection
            number={4}
            title="Product Demos & Client Meetings"
            timeRange="2:15 - 5:15 PM"
            icon={Presentation}
            isExpanded={expandedSections.includes(4)}
            onToggle={() => toggleSection(4)}
            hasContent={watchedValues.zoomDemosConducted > 0 || watchedValues.clientsMet > 0}
          >
            <div className="grid gap-4 md:grid-cols-2">
              <NumberInput label="Zoom/Onsite demos conducted" name="zoomDemosConducted" form={form} />
              <NumberInput label="Clients met" name="clientsMet" form={form} />
            </div>
            <FormField
              control={form.control}
              name="pricingExplained"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Pricing/features explained</FormLabel>
                    <p className="text-sm text-muted-foreground">
                      Did you explain pricing and features?
                    </p>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      data-testid="switch-pricing-explained"
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="testimonialsShared"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Testimonials/success stories shared</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Enter testimonials shared..."
                      {...field}
                      data-testid="input-testimonials-shared"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </FormSection>

          <FormSection
            number={5}
            title="Quotation / Proposal / Invoice Sending"
            timeRange="5:15 - 5:45 PM"
            icon={FileText}
            isExpanded={expandedSections.includes(5)}
            onToggle={() => toggleSection(5)}
            hasContent={
              watchedValues.quotationsSent > 0 ||
              watchedValues.proposalsCreated > 0 ||
              watchedValues.invoicesShared > 0
            }
          >
            <div className="grid gap-4 md:grid-cols-3">
              <NumberInput label="Quotations sent" name="quotationsSent" form={form} />
              <NumberInput label="Proposals created" name="proposalsCreated" form={form} />
              <NumberInput label="Invoices shared" name="invoicesShared" form={form} />
            </div>
            <FormField
              control={form.control}
              name="leadStatus"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Lead status updated</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value || ""}>
                    <FormControl>
                      <SelectTrigger data-testid="select-lead-status">
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="negotiation">Negotiation</SelectItem>
                      <SelectItem value="waiting">Waiting</SelectItem>
                      <SelectItem value="decision">Decision</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                      <SelectItem value="lost">Lost</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </FormSection>

          <FormSection
            number={6}
            title="Daily Wrap-Up"
            timeRange="5:45 - 6:00 PM"
            icon={CheckCircle}
            isExpanded={expandedSections.includes(6)}
            onToggle={() => toggleSection(6)}
            hasContent={
              watchedValues.totalCalls > 0 ||
              watchedValues.totalDemos > 0 ||
              watchedValues.leadsConverted > 0
            }
          >
            <div className="grid gap-4 md:grid-cols-3">
              <NumberInput label="Total calls" name="totalCalls" form={form} />
              <NumberInput label="Total demos" name="totalDemos" form={form} />
              <NumberInput label="Leads converted" name="leadsConverted" form={form} />
            </div>
            <FormField
              control={form.control}
              name="pendingFollowUp"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pending follow-up tasks for tomorrow</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="List pending follow-up tasks..."
                      {...field}
                      data-testid="input-pending-follow-up"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes / Remarks</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Any additional notes..."
                      {...field}
                      data-testid="input-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </FormSection>

          <Card className="sticky bottom-4">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-6 text-sm">
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{watchedValues.totalCalls || 0}</span>
                    <span className="text-muted-foreground">calls</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Presentation className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{watchedValues.totalDemos || 0}</span>
                    <span className="text-muted-foreground">demos</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{watchedValues.leadsConverted || 0}</span>
                    <span className="text-muted-foreground">converted</span>
                  </div>
                </div>
                <div className="flex gap-3 w-full sm:w-auto">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate("/reports")}
                    className="flex-1 sm:flex-initial"
                    data-testid="button-cancel"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={isPending}
                    className="flex-1 sm:flex-initial"
                    data-testid="button-submit-report"
                  >
                    {isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    {isEditing ? "Update Report" : "Submit Report"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </form>
      </Form>
    </div>
  );
}
