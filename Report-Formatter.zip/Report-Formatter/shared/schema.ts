import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, date, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const dailyReports = pgTable("daily_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  date: text("date").notNull(),
  executiveName: text("executive_name").notNull(),
  
  targetForToday: text("target_for_today"),
  yesterdayPerformance: text("yesterday_performance"),
  newLeadsAssigned: text("new_leads_assigned"),
  
  leadsAddedToCRM: integer("leads_added_to_crm").default(0),
  leadSource: text("lead_source"),
  introductionsSent: integer("introductions_sent").default(0),
  
  totalCallsMade: integer("total_calls_made").default(0),
  meaningfulConversations: integer("meaningful_conversations").default(0),
  whatsappMessagesSent: integer("whatsapp_messages_sent").default(0),
  emailsSent: integer("emails_sent").default(0),
  freeDemosOffered: integer("free_demos_offered").default(0),
  demosScheduled: text("demos_scheduled"),
  
  zoomDemosConducted: integer("zoom_demos_conducted").default(0),
  clientsMet: integer("clients_met").default(0),
  pricingExplained: boolean("pricing_explained").default(false),
  testimonialsShared: text("testimonials_shared"),
  
  quotationsSent: integer("quotations_sent").default(0),
  proposalsCreated: integer("proposals_created").default(0),
  invoicesShared: integer("invoices_shared").default(0),
  leadStatus: text("lead_status"),
  
  totalCalls: integer("total_calls").default(0),
  totalDemos: integer("total_demos").default(0),
  leadsConverted: integer("leads_converted").default(0),
  pendingFollowUp: text("pending_follow_up"),
  notes: text("notes"),
});

export const insertDailyReportSchema = createInsertSchema(dailyReports).omit({
  id: true,
});

export type InsertDailyReport = z.infer<typeof insertDailyReportSchema>;
export type DailyReport = typeof dailyReports.$inferSelect;
