import { type User, type InsertUser, type DailyReport, type InsertDailyReport, users, dailyReports } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllReports(): Promise<DailyReport[]>;
  getReportById(id: string): Promise<DailyReport | undefined>;
  createReport(report: InsertDailyReport): Promise<DailyReport>;
  updateReport(id: string, report: InsertDailyReport): Promise<DailyReport | undefined>;
  deleteReport(id: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getAllReports(): Promise<DailyReport[]> {
    return await db.select().from(dailyReports).orderBy(desc(dailyReports.date));
  }

  async getReportById(id: string): Promise<DailyReport | undefined> {
    const result = await db.select().from(dailyReports).where(eq(dailyReports.id, id));
    return result[0];
  }

  async createReport(insertReport: InsertDailyReport): Promise<DailyReport> {
    const result = await db.insert(dailyReports).values(insertReport).returning();
    return result[0];
  }

  async updateReport(id: string, insertReport: InsertDailyReport): Promise<DailyReport | undefined> {
    const result = await db.update(dailyReports)
      .set(insertReport)
      .where(eq(dailyReports.id, id))
      .returning();
    return result[0];
  }

  async deleteReport(id: string): Promise<boolean> {
    const result = await db.delete(dailyReports).where(eq(dailyReports.id, id)).returning();
    return result.length > 0;
  }
}

export const storage = new DatabaseStorage();
