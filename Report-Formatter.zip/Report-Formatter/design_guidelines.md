# Daily Sales Report Management System - Design Guidelines

## Design Approach

**Selected Approach:** Design System + Productivity App Reference

**Justification:** This is a utility-focused, data-entry intensive application requiring efficiency, clarity, and daily consistency. Drawing inspiration from Linear's clean precision and Notion's form handling, while maintaining a professional sales-focused aesthetic.

**Key Design Principles:**
- Speed-optimized data entry with logical flow
- Scannable information hierarchy for quick review
- Clear visual separation between form sections
- Professional but approachable aesthetic for daily use

## Typography

**Font Family:** Inter (via Google Fonts CDN)
- Primary: Inter (400, 500, 600, 700)

**Type Scale:**
- Page Headers: text-2xl font-semibold (Dashboard, Reports)
- Section Headers: text-lg font-semibold (Morning Sync, Lead Generation, etc.)
- Form Labels: text-sm font-medium
- Input Text: text-base
- Metrics/Numbers: text-3xl font-bold (dashboard stats), text-xl font-semibold (section totals)
- Helper Text: text-xs text-gray-600

## Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12
- Form field spacing: space-y-4
- Section padding: p-6
- Card gaps: gap-6
- Page margins: px-6 py-8
- Component spacing: mb-8

**Container Strategy:**
- Main container: max-w-7xl mx-auto
- Form sections: max-w-4xl (optimal for single-column forms)
- Dashboard grid: Full width with responsive grid

## Component Library

### Navigation
**Sidebar Navigation** (desktop) / **Bottom Tab Bar** (mobile)
- Dashboard (home icon)
- New Report (plus icon)
- View Reports (document icon)
- Profile/Settings (user icon)
- Active state with accent indicator
- Icons: Heroicons

### Dashboard Cards
**Metric Cards** (4-column grid on desktop, 2-column on tablet, 1-column mobile)
- Large number display at top
- Metric label below
- Small trend indicator (optional: "vs yesterday")
- Subtle border, rounded corners (rounded-lg)
- Padding: p-6

**Activity Summary Card**
- Table format showing recent activity
- Columns: Date, Executive, Calls, Demos, Conversions
- Clickable rows to view full report
- Zebra striping for readability

### Form Components

**Report Form Layout**
- Single-column layout for clarity
- 6 distinct sections matching the daily schedule
- Each section in a card with header and collapsed/expanded state
- Section header shows time range (e.g., "9:00-9:30 AM")

**Section Cards:**
- White background, border, rounded-lg
- Section number badge (1-6) with time
- Collapsible with chevron icon
- Padding: p-6

**Input Fields:**
- Text inputs: Full width with label above, rounded-md border
- Number inputs: Smaller width (w-32) for counts
- Textarea: For notes/remarks, min-h-24
- Dropdowns: For lead status, demo type
- Date picker: For report date selection
- All inputs: px-4 py-2, focus ring

**Input Groups:**
- Related inputs grouped horizontally where logical (e.g., calls made + meaningful conversations)
- Grid layout: grid-cols-2 gap-4 (mobile: grid-cols-1)

### Buttons
**Primary Button** (Submit Report, Save)
- px-6 py-3, rounded-md, font-medium
- Full width on mobile

**Secondary Button** (Cancel, Back)
- px-6 py-3, rounded-md, border

**Icon Buttons** (Edit, Delete in reports list)
- p-2, rounded

### Data Display

**Report View Card**
- Same structure as form but read-only
- Edit button in header
- Metrics displayed as: "Label: Value" pairs
- Section totals calculated at bottom

**Summary Statistics Bar**
- Sticky bar at form bottom showing real-time totals
- Total Calls | Total Demos | Leads Converted
- Updates as user fills form

### Tables
**Reports List Table**
- Full-width responsive table
- Columns: Date, Executive, Total Calls, Demos, Conversions, Actions
- Sortable headers
- Row hover state
- Action buttons (View, Edit, Delete) right-aligned

**Filters & Search:**
- Horizontal filter bar above table
- Date range picker + Executive name dropdown + Search
- Clear filters button

### Empty States
- Centered icon (from Heroicons)
- Primary message (text-lg font-medium)
- Secondary instruction text
- CTA button to create first report

## Images

**No hero images** - This is a data-focused web application, not a marketing site.

**Icon Usage:**
- Heroicons throughout for UI actions and navigation
- Section icons for each of the 6 daily activities (clock, phone, presentation, document, etc.)

## Responsive Behavior

**Desktop (lg):**
- Sidebar navigation (fixed left, w-64)
- Dashboard: 4-column metric grid
- Form: Centered, max-w-4xl, 2-column input grids where appropriate

**Tablet (md):**
- Sidebar collapses to icon-only or hamburger
- Dashboard: 2-column grid
- Form: 2-column input grids

**Mobile (base):**
- Bottom tab navigation
- Dashboard: 1-column cards, stacked
- Form: All single column, full-width inputs
- Sticky "Save" button at bottom

## Animations

**Minimal Motion:**
- Section expand/collapse: smooth height transition (duration-200)
- Button hover: subtle scale or opacity change
- No page transitions or decorative animations

## Special Considerations

**Form Autosave Indicator:**
- Small "Saved" checkmark or "Saving..." indicator
- Positioned near submit button

**Validation:**
- Inline error messages below invalid fields
- Error state: red border on input
- Success state: Subtle green checkmark

**Progress Indication:**
- Linear progress bar showing form completion (e.g., "4/6 sections completed")
- Positioned at top of form